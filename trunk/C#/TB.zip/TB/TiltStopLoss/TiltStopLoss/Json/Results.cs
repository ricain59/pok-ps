﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace StopLoss.Json
{
    class Results
    {
        public String NewStarsVPP { get; set; }
        public String Rake { get; set; }
    }
}
