using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        const string ratingText = "Current Rating : # out of %, Old Rating : $";
        private void ratingBar1_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label1.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar2_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label2.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar3_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label3.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar4_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label4.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar5_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label5.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar6_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label7.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void ratingBar7_RateChanged(object sender, XSystem.WinControls.RatingBarRateEventArgs e)
        {
            label6.Text = ratingText.Replace("#", e.NewRate.ToString()).Replace("%", ((XSystem.WinControls.RatingBar)sender).IconsCount.ToString()).Replace("$", e.OldRate.ToString());
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //ratingBar1.Rate = 10.5f; // testing exception
        }
    }
}