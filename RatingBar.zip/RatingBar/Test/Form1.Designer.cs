namespace Test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.ratingBar2 = new XSystem.WinControls.RatingBar();
            this.ratingBar1 = new XSystem.WinControls.RatingBar();
            this.ratingBar3 = new XSystem.WinControls.RatingBar();
            this.ratingBar4 = new XSystem.WinControls.RatingBar();
            this.ratingBar5 = new XSystem.WinControls.RatingBar();
            this.ratingBar6 = new XSystem.WinControls.RatingBar();
            this.ratingBar7 = new XSystem.WinControls.RatingBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ratingBar2
            // 
            this.ratingBar2.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar2.Gap = ((byte)(1));
            this.ratingBar2.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar2.IconEmpty")));
            this.ratingBar2.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar2.IconFull")));
            this.ratingBar2.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar2.IconHalf")));
            this.ratingBar2.IconsCount = ((byte)(10));
            this.ratingBar2.IconStyle = XSystem.WinControls.IconStyle.Heart;
            this.ratingBar2.Location = new System.Drawing.Point(145, 78);
            this.ratingBar2.Name = "ratingBar2";
            this.ratingBar2.Rate = 0F;
            this.ratingBar2.Size = new System.Drawing.Size(185, 37);
            this.ratingBar2.TabIndex = 1;
            this.ratingBar2.Text = "ratingBar2";
            this.ratingBar2.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar2_RateChanged);
            // 
            // ratingBar1
            // 
            this.ratingBar1.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar1.Gap = ((byte)(1));
            this.ratingBar1.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar1.IconEmpty")));
            this.ratingBar1.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar1.IconFull")));
            this.ratingBar1.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar1.IconHalf")));
            this.ratingBar1.IconsCount = ((byte)(10));
            this.ratingBar1.Location = new System.Drawing.Point(145, 35);
            this.ratingBar1.Name = "ratingBar1";
            this.ratingBar1.Rate = 0F;
            this.ratingBar1.Size = new System.Drawing.Size(185, 37);
            this.ratingBar1.TabIndex = 2;
            this.ratingBar1.Text = "ratingBar1";
            this.ratingBar1.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar1_RateChanged);
            // 
            // ratingBar3
            // 
            this.ratingBar3.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar3.Gap = ((byte)(1));
            this.ratingBar3.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar3.IconEmpty")));
            this.ratingBar3.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar3.IconFull")));
            this.ratingBar3.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar3.IconHalf")));
            this.ratingBar3.IconsCount = ((byte)(10));
            this.ratingBar3.IconStyle = XSystem.WinControls.IconStyle.Misc;
            this.ratingBar3.Location = new System.Drawing.Point(145, 121);
            this.ratingBar3.Name = "ratingBar3";
            this.ratingBar3.Rate = 0F;
            this.ratingBar3.Size = new System.Drawing.Size(185, 37);
            this.ratingBar3.TabIndex = 3;
            this.ratingBar3.Text = "ratingBar3";
            this.ratingBar3.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar3_RateChanged);
            // 
            // ratingBar4
            // 
            this.ratingBar4.Alignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ratingBar4.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar4.Gap = ((byte)(1));
            this.ratingBar4.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar4.IconEmpty")));
            this.ratingBar4.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar4.IconFull")));
            this.ratingBar4.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar4.IconHalf")));
            this.ratingBar4.IconsCount = ((byte)(5));
            this.ratingBar4.Location = new System.Drawing.Point(145, 164);
            this.ratingBar4.Name = "ratingBar4";
            this.ratingBar4.Rate = 0F;
            this.ratingBar4.Size = new System.Drawing.Size(185, 37);
            this.ratingBar4.TabIndex = 4;
            this.ratingBar4.Text = "ratingBar4";
            this.ratingBar4.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar4_RateChanged);
            // 
            // ratingBar5
            // 
            this.ratingBar5.Alignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.ratingBar5.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar5.Gap = ((byte)(1));
            this.ratingBar5.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar5.IconEmpty")));
            this.ratingBar5.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar5.IconFull")));
            this.ratingBar5.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar5.IconHalf")));
            this.ratingBar5.IconsCount = ((byte)(4));
            this.ratingBar5.Location = new System.Drawing.Point(145, 207);
            this.ratingBar5.Name = "ratingBar5";
            this.ratingBar5.Rate = 0F;
            this.ratingBar5.Size = new System.Drawing.Size(185, 37);
            this.ratingBar5.TabIndex = 5;
            this.ratingBar5.Text = "ratingBar5";
            this.ratingBar5.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar5_RateChanged);
            // 
            // ratingBar6
            // 
            this.ratingBar6.Alignment = System.Drawing.ContentAlignment.BottomCenter;
            this.ratingBar6.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar6.Gap = ((byte)(1));
            this.ratingBar6.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar6.IconEmpty")));
            this.ratingBar6.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar6.IconFull")));
            this.ratingBar6.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar6.IconHalf")));
            this.ratingBar6.IconsCount = ((byte)(6));
            this.ratingBar6.Location = new System.Drawing.Point(145, 293);
            this.ratingBar6.Name = "ratingBar6";
            this.ratingBar6.Rate = 0F;
            this.ratingBar6.Size = new System.Drawing.Size(185, 37);
            this.ratingBar6.TabIndex = 7;
            this.ratingBar6.Text = "ratingBar6";
            this.ratingBar6.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar6_RateChanged);
            // 
            // ratingBar7
            // 
            this.ratingBar7.Alignment = System.Drawing.ContentAlignment.BottomRight;
            this.ratingBar7.BarBackColor = System.Drawing.Color.DarkGray;
            this.ratingBar7.Gap = ((byte)(1));
            this.ratingBar7.IconEmpty = ((System.Drawing.Image)(resources.GetObject("ratingBar7.IconEmpty")));
            this.ratingBar7.IconFull = ((System.Drawing.Image)(resources.GetObject("ratingBar7.IconFull")));
            this.ratingBar7.IconHalf = ((System.Drawing.Image)(resources.GetObject("ratingBar7.IconHalf")));
            this.ratingBar7.IconsCount = ((byte)(5));
            this.ratingBar7.Location = new System.Drawing.Point(145, 250);
            this.ratingBar7.Name = "ratingBar7";
            this.ratingBar7.Rate = 0F;
            this.ratingBar7.Size = new System.Drawing.Size(185, 37);
            this.ratingBar7.TabIndex = 6;
            this.ratingBar7.Text = "ratingBar7";
            this.ratingBar7.RateChanged += new XSystem.WinControls.OnRateChanged(this.ratingBar7_RateChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(336, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(336, 102);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(336, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(336, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(336, 231);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 13);
            this.label5.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(336, 274);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 13);
            this.label6.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(336, 317);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(12, 317);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Alignment : Bottom Center";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(12, 274);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 13);
            this.label9.TabIndex = 20;
            this.label9.Text = "Alignment : Bottom Right";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(12, 231);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 13);
            this.label10.TabIndex = 19;
            this.label10.Text = "Alignment : Middle Left";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(12, 188);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(114, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "Alignment : Middle Left";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(12, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Alignment : Middle Center";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(12, 102);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 13);
            this.label13.TabIndex = 16;
            this.label13.Text = "Alignment : Middle Center";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(12, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 13);
            this.label14.TabIndex = 15;
            this.label14.Text = "Alignment : Middle Center";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(640, 354);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ratingBar6);
            this.Controls.Add(this.ratingBar7);
            this.Controls.Add(this.ratingBar5);
            this.Controls.Add(this.ratingBar4);
            this.Controls.Add(this.ratingBar3);
            this.Controls.Add(this.ratingBar1);
            this.Controls.Add(this.ratingBar2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private XSystem.WinControls.RatingBar ratingBar2;
        private XSystem.WinControls.RatingBar ratingBar1;
        private XSystem.WinControls.RatingBar ratingBar3;
        private XSystem.WinControls.RatingBar ratingBar4;
        private XSystem.WinControls.RatingBar ratingBar5;
        private XSystem.WinControls.RatingBar ratingBar6;
        private XSystem.WinControls.RatingBar ratingBar7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
    }
}

